class NumCheck {

	public static void main(String[] args) {

		int a = 30, b = 20;

		if(a > b)//true
			System.out.println("a is greater than b");//print

		else if(a == b)
			System.out.println("a is equal to b");

		else 
			System.out.println("a is less than b");

	}


}
