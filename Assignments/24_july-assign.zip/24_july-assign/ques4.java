class VowelCheck {

	public static void main(String[] args) {

		char ch = 'A';

		if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')//true
			System.out.println(ch + " is vowel");//print

		else 
			System.out.println(ch + " is consonant");

	}


}
