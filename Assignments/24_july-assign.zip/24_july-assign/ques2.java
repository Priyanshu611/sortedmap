class AngleCheck {

	public static void main(String[] args) {

		int Angle = 20;

		if(Angle <= 90)
			System.out.println("Acute Angle");

		else if(Angle == 90)
			System.out.println("Right Angle");

		else 
			System.out.println("Obtuse Angle");

	}


}
