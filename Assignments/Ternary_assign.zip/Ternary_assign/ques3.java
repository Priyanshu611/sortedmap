class Ternary3 {

	public static void main(String[] args){

		int num = 17;
		String ans = null;

		ans = (num>18) ? "Eligible for voting" : "Not eligible for voting";
		
		System.out.println(ans);
	}

}
