class Ternary4 {


	public static void main(String[] args){

		int x = 25, y = 40, z = 52;
	        int ans = 0;

		ans = (x>y) ? ((x>z) ? x : z) : ((y>z) ? y : z); //x

		System.out.println(ans);




	}


}
