class Ternary2 {


	public static void main(String[] args){

		int x = 5, y = 20;

		System.out.println((x<y) ? x : y); //5<20 = true


	}


}
