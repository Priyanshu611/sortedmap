class Ternary3 {


	public static void main(String[] args){

		int x = 15, y = 25;
	        String ans =  null;

		ans = (x<y) ? "x is smaller" : "y is greater"; //x is smaller

		System.out.println(ans);




	}


}
