class Ternary1 {


	public static void main(String[] args){

		int x = 25, y = 20, res = 0;

		res = (x<y) ? x : y; //25<20 = false

		System.out.println(res);




	}


}
