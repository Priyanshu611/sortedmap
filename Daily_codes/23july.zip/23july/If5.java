class IF5 {


	public static void main(String[] args) {

		boolean x = true, y = false;

		if(x && y) { //false

			System.out.println("Hiii..");

		}

		System.out.println("Out of If-statement");//print

	}

}
