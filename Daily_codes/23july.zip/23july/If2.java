class IF2 {


	public static void main(String[] args) {

		int x = 10, y = 20;

		if(x<y) {

			System.out.println("X is smaller");

		}

		System.out.println("Out of If-statement");

	}

}
