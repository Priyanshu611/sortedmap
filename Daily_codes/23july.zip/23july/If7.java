class IF7 {


	public static void main(String[] args) {

		int x = 10;

		if(x<10)  //false
	                System.out.println("In IF");// don't print
			System.out.println("hii...");//print
			

		System.out.println("Out of If-else statement");//print

	}

}
