class IF4 {


	public static void main(String[] args) {

		int x = 10;

		if(x++ <= 10) { //true

			System.out.println("Hiii..");//print

		}

		System.out.println("Out of If-statement");//print

	}

}
