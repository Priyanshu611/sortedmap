class IF1 {


	public static void main(String[] args) {

		int x = 30, y = 20;

		if(x<y) {

			System.out.println("X is smaller");

		}

		System.out.println("Out of If-statement");

	}

}
