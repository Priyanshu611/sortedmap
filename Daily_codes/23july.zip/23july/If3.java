class IF3 {


	public static void main(String[] args) {

		int x = 10;

		if(++x <= 10) { //false

			System.out.println("Hiii..");

		}

		System.out.println("Out of If-statement");

	}

}
