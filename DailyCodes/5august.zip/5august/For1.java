class For1 {

	public static void main(String[] args){

		/*
			for(intialization; condition; inc/dec){

				statement;

			}

		*/

		for(int i = 1; i <= 10; i++){

			System.out.println(i*i);

		}

	}


}
