class For4 {

	public static void main(String[] args){

		/*
			for(intialization; condition; inc/dec){

				statement;

			}

		*/

		for(int i = 1; i <= 100; i++){

			if(i%4==0 || i%12==0)// statement of for but if's condition
				System.out.println(i);

		}

	}


}
